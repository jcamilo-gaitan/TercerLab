package com.Laboratorio3.zoo_fantastico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZooFantasticoApplicationTests {

	@Test
	void contextLoads() {
	}

}
