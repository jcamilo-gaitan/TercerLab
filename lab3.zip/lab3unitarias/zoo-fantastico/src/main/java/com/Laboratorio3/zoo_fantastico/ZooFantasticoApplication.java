package com.Laboratorio3.zoo_fantastico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZooFantasticoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZooFantasticoApplication.class, args);
	}

}
