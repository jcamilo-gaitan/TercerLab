package com.Laboratorio3.zoo_fantastico.repository;

import com.Laboratorio3.zoo_fantastico.entity.Zone;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ZoneRepository extends JpaRepository<Zone, Long> {}
